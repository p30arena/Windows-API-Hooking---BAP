// dllmain.cpp : Defines the entry point for the DLL application.

#include "stdafx.h"
#include <cstdlib>
#include <cstdio>
#include <assert.h>
#include <Windows.h>

#include <Dbghelp.h>
#include <TlHelp32.h>
#include <Psapi.h>

#include "APIHook.h"

#include <Winsock2.h>

///////////////////////////////////////////////////////////////////////////////

char ADDR[40];
BOOL str_appropriate = TRUE;


char** str_split(char* a_str, const char a_delim)
{
    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = (char**)malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, ".");

        while (token)
        {
            assert(idx < count);
            *(result + idx++) = _strdup(token);
            token = strtok(0, ".");
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }

    return result;
}



BOOL parse_addr(PSOCKADDR_IN si)
{
	char _str_tk[40];
	if(!str_appropriate)
		return FALSE;
	strcpy_s(_str_tk, 40, ADDR);
	size_t len = strlen(ADDR);
	char **tokens;
	char buffer[5][7];
	tokens = str_split(_str_tk, '.');
	if(tokens)
	{
		int i;
        for (i = 0; *(tokens + i); i++)
        {
			if(i>4)
				return FALSE;
			strcpy(buffer[i], *(tokens+i));
            free(*(tokens + i));
        }
        free(tokens);
	}
	si->sin_port = htons(atoi(buffer[4]));
	si->sin_addr.S_un.S_un_b.s_b1 = (UCHAR)atoi(buffer[0]);
	si->sin_addr.S_un.S_un_b.s_b2 = (UCHAR)atoi(buffer[1]);
	si->sin_addr.S_un.S_un_b.s_b3 = (UCHAR)atoi(buffer[2]);
	si->sin_addr.S_un.S_un_b.s_b4 = (UCHAR)atoi(buffer[3]);
	return TRUE;
}


//-------------------------
extern CAPIHook g_connect;

typedef int (WINAPI*_connect)(
  _In_  SOCKET s,
  _In_  const struct sockaddr *name,
  _In_  int namelen
);
int WINAPI Hook_connect(_In_  SOCKET s,
  _In_  const SOCKADDR *name,
  _In_  int namelen
)
{
	_connect con = (_connect)(PROC)g_connect;
	PSOCKADDR_IN si = (PSOCKADDR_IN)name;
	
	//MessageBox(0,L"Hooked: 'connect'", L"", 0);

	parse_addr(si);
	return con(s, (PSOCKADDR)si, namelen);
}

CAPIHook g_connect("ws2_32.dll", "connect",
   (PROC) Hook_connect);

///////////////////////////////////////////////////////////////////////////////


BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	HANDLE file;
	DWORD rlen = 0;
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			file = CreateFile(
				L"test.txt",
				GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_DELETE,
				NULL,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL,
				NULL);
			if(file != INVALID_HANDLE_VALUE)
			{
				if(!ReadFile(file, ADDR, 30, &rlen, NULL))
				{
					str_appropriate = FALSE;
					strcpy_s(ADDR, 33,"ERROR FETCHING ADDRESS FROM FILE");
				}
				MessageBoxA(NULL, ADDR, "Address to change to", 0);
			}
			else
			{
				str_appropriate = FALSE;
				MessageBoxA(NULL, "Error Openning the file", "Address to change to", 0);
			}
			CloseHandle(file);
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}

