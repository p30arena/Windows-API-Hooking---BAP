// inject.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define PATH L"C:\\Python27\\python.exe"
#define DIR L"C:\\Python27"

typedef struct LIST_PROC{
	HANDLE hProcess;
	HANDLE hThread;
};

LIST_PROC lst[1] = {{INVALID_HANDLE_VALUE, INVALID_HANDLE_VALUE}};


BOOL INJECT(LIST_PROC *P, PWSTR pszLibFileRemote)
{
	STARTUPINFO startupInfo;
	PROCESS_INFORMATION procInfo;
	ZeroMemory( &startupInfo, sizeof(startupInfo) );
    startupInfo.cb = sizeof(startupInfo);
    ZeroMemory( &procInfo, sizeof(procInfo) );
	CreateProcess(PATH, NULL, NULL, NULL, FALSE, 0, NULL, DIR, &startupInfo, &procInfo);
	P->hProcess = procInfo.hProcess;
	P->hThread = procInfo.hThread;
	Sleep(5000);
	//inject code
	//PCWSTR pszLibFile = L"C:\\injector\\Debug\\injector.dll";
	PCWSTR pszLibFile = L"injector.dll";
	int cch = 1 + lstrlenW(pszLibFile);
	int cb = cch * sizeof(wchar_t);
	pszLibFileRemote = (PWSTR)VirtualAllocEx(procInfo.hProcess, NULL, cb, MEM_COMMIT, PAGE_READWRITE);
	if (pszLibFileRemote == NULL) return FALSE;
	if(!WriteProcessMemory(procInfo.hProcess, pszLibFileRemote, (PVOID)pszLibFile, cb, NULL)) return FALSE;
	PTHREAD_START_ROUTINE pfnThreadRtn = (PTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(TEXT("Kernel32")), "LoadLibraryW");
	if (pfnThreadRtn == NULL) return FALSE;
	HANDLE hThread = CreateRemoteThread(procInfo.hProcess, NULL, 0, pfnThreadRtn, pszLibFileRemote, 0, NULL);
	if (hThread == NULL) return FALSE;
}
int _tmain(int argc, _TCHAR* argv[])
{
	//getProcessByName();
	//
	PWSTR pszLibFileRemote = NULL;
	if(INJECT(&lst[0], pszLibFileRemote))printf("injected");
	WaitForSingleObject( lst[0].hProcess, INFINITE );
	CloseHandle( lst[0].hProcess );
	CloseHandle( lst[0].hThread );


	perror("inject failed");
	if(pszLibFileRemote != NULL)
		VirtualFreeEx(lst[0].hProcess, pszLibFileRemote, 0, MEM_RELEASE);
	return 0;
}

